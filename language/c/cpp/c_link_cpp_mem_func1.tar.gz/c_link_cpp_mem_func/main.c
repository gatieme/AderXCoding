#include <stdio.h>
#include <stdlib.h>


extern int call_cpp_class_add(int a, int b);



int main(void)
{
    printf("2 + 4 = %d\n", call_cpp_class_add(2, 4));

    return 0;
}
