#include <iostream>

using namespace std;


class MyClass
{
public :
    //  member function
    int add(int a, int b)
    {
        return (a + b);
    }
};
