

#include "myclass.h"


//  member function
int MyClass::add(int a, int b)
{
    return (a + b);
}


/*
#include <iostream>

class MyClass
{
    //  member function
    int add(int a, int b)
    {
        return (a + b);
    }
};
*/
