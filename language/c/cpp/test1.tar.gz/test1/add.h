#ifndef __ADD_H_INCLUDE__
#define __ADD_H_INCLUDE__


#include <iostream>

//using namespace std;



int add(const int a, int b);

#endif  //  __ADD_H_INCLUDE__
