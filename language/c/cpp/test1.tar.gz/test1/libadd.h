#ifndef __LIBADD_H_INCLUDE__
#define __LIBADD_H_INCLUDE__

#include "add.h"
//extern int add(const int a, const int b);

#ifdef __cplusplus
extern "C"
{
#endif

int call_cpp_add(const int a, const int b);


#ifdef __cplusplus
}
#endif


#endif  //  #define __LIBADD_H_INCLUDE__
