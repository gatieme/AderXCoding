

#include "add.h"

int add(const int a, const int b)
{
    return (a + b);
}
